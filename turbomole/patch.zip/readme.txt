Win64
1. Copy turbo_license.ctd to COSMOlogic\TmoleX16\TURBOMOLE\LICENSE
2. Run TM7.1Win64-patch.exe in COSMOlogic\TmoleX16\TURBOMOLE\bin\winnt
3. If you need to carry out multi-core computing, in COSMOlogic\TmoleX16\TURBOMOLE\bin\winnt_smp run TM7.1Win64smp-patch.exe

Lin64
1. Copy turbo_license.ctd to COSMOlogic/TmoleX16/TURBOMOLE/LICENSE
2. Copy the directory COSMOlogic/TmoleX16/TURBOMOLE/bin/em64t-unknown-linux-gnu to Windows machine, run TM7.1Lin64-patch.exe , and then return to the Linux system to overwrite the original file, and set the the correct execution authority.
3. If you need to carry out multi-core computing, run COSMOlogic/TmoleX16/TURBOMOLE/bin/em64t-unknown-linux-gnu_mpi and COSMOlogic/TmoleX16/TURBOMOLE/bin/em64t-unknown-linux-gnu_smp the same way.